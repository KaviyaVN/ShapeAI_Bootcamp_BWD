import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>This Bootcamp is about a basic web development and React js</p>
    </div>
  );
}

export default Info;
